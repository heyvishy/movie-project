package com.jpmc.theater;

import org.junit.jupiter.api.Test;

import com.jpmc.theater.domain.Customer;
import com.jpmc.theater.domain.Reservation;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TheaterTests {

    @Test
    void verifyTotalFeeForCustomer() {
        Theater theater = new Theater();
        Customer john = new Customer("John Doe", "id-12345");
        Reservation reservation = theater.reserve(john, 2, 4);
        assertEquals(reservation.totalFee(), 50);
    }

    @Test
    void verifyPrintMovieSchedule() {
        Theater theater = new Theater();
        theater.printSchedule();
        theater.printScheduleJson();
    }
}
