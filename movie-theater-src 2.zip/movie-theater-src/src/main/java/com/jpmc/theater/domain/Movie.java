package com.jpmc.theater.domain;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.time.Duration;
import java.time.LocalTime;

@AllArgsConstructor
@EqualsAndHashCode
@Getter
public class Movie {
    private static int MOVIE_CODE_SPECIAL = 1;

    private String title;
    private Duration runningTime;
    private double ticketPrice;
    private int specialCode;

    public double calculateTicketPrice(Showing showing) {
        return ticketPrice - getDiscount(showing);
    }

    private double getDiscount(Showing showing) {
        double specialDiscount = getSpecialDiscount();
        double startTimeDiscount = getStartTimeDiscount(showing);
        double sequenceDiscount = getSequenceDiscount(showing);

        // biggest discount wins
        return Math.max(startTimeDiscount, Math.max(specialDiscount, sequenceDiscount));
    }

    private double getSpecialDiscount() {
        return MOVIE_CODE_SPECIAL == specialCode ? ticketPrice * 0.2 : 0; // 20% discount for special movie
    }

    private double getStartTimeDiscount(Showing showing) {
        double startTimeDiscount = 0;
        LocalTime startRange = LocalTime.of(11,0);
        LocalTime endRange = LocalTime.of(16,0);
        LocalTime showStartTime = showing.getStartTime().toLocalTime();

        if ((showStartTime.isAfter(startRange) || showStartTime.equals(startRange)) &&
                (showStartTime.isBefore(endRange) || showStartTime.equals(endRange))) {
            startTimeDiscount = ticketPrice * 0.25;  // 25% discount for show between 11am-4pm
        }
        return startTimeDiscount;
    }

    private double getSequenceDiscount(Showing showing) {
        double sequenceDiscount = 0;
        if (showing.getSequenceOfTheDay() == 1) {
            sequenceDiscount = 3; // $3 discount for 1st show
        } else if (showing.getSequenceOfTheDay() == 2) {
            sequenceDiscount = 2; // $2 discount for 2nd show
        } else if (showing.getSequenceOfTheDay() == 7) {
            sequenceDiscount = 1; // $1 discount for 7th show
        }
        return sequenceDiscount;
    }

}